package com.example.universoguias.PaginasPrincipales

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import com.example.universoguias.R
import com.example.universoguias.utils.PaginaPrincipal
import kotlinx.android.synthetic.main.activity_juegosmasfamosos.*
import kotlinx.android.synthetic.main.container.*

class Patreon : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_patreon)
        setSupportActionBar(toolbar)
        btnvolverahome0.setOnClickListener{
            returnActivity()
            return@setOnClickListener
        }
    }
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {

        menuInflater.inflate(R.menu.navmenu, menu)
        menuInflater.inflate(R.menu.menu_search, menu)

        return super.onCreateOptionsMenu(menu)
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_search -> Log.i("PaginaPrincipal", "Search")
            R.id.action_search -> Log.i("SagasdeVideojuegos", "Search")
            R.id.action_search -> Log.i("SagaResidentEvil", "Search")
            R.id.action_search -> Log.i("GuiaResidentEvil1", "Search")
        }
        return super.onOptionsItemSelected(item)
    }
    fun returnActivity() {
        startActivity(Intent(this, PaginaPrincipal::class.java))
        finish()
        return
    }
}