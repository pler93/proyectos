package com.example.universoguias.GuiaResidentEvil1


import com.google.gson.annotations.SerializedName

data class ResidentEvil1(
    @SerializedName("data")
    val `data`: List<Data>
)