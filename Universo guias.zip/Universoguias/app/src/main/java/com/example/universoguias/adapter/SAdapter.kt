package com.example.universoguias.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.universoguias.R
import com.example.universoguias.modelsRE1.v2.Saga
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.item_residentevil.view.*
import kotlinx.android.synthetic.main.item_residentevil1.view.*

class SAdapter(var mDataSet: List<Saga>, var onClick: (Saga)->Unit) :
    RecyclerView.Adapter<SAdapter.MainViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MainViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_residentevil, parent, false)
        return MainViewHolder(v)
    }

    override fun onBindViewHolder(holder: MainViewHolder, position: Int) {
        val data = mDataSet.get(position)
        holder.bindItems(data)
        holder.itemView.setOnClickListener{
            onClick(data)
        }
    }

    override fun getItemCount(): Int {
        return mDataSet.size
    }

    inner class MainViewHolder(var v: View) : RecyclerView.ViewHolder(v) {
        fun bindItems(data: Saga) {
            v.tvTextSRE.text = data.nombre
            // v.tvaño.text = data.año
            Picasso.get().load(data?.foto).into(v.ivResidentEvil)
        }
    }
}