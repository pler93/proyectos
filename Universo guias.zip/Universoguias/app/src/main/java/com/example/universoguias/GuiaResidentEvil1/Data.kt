package com.example.universoguias.GuiaResidentEvil1


import com.google.gson.annotations.SerializedName

data class Data(
    @SerializedName("año")
    val año: String,
    @SerializedName("chris campaign")
    val chrisCampaign: ChrisCampaign,
    @SerializedName("gratitudes written guia")
    val gratitudesWrittenGuia: String,
    @SerializedName("gratitudes youtube")
    val gratitudesYoutube: String,
    @SerializedName("image")
    val image: Image,
    @SerializedName("synopsis")
    val synopsis: String,
    @SerializedName("thanks to the capcom company")
    val thanksToTheCapcomCompany: String,
    @SerializedName("title")
    val title: String,
    @SerializedName("write guide url")
    val writeGuideUrl: String,
    @SerializedName("writenn resident evil 1 cheats pc")
    val writennResidentEvil1CheatsPc: WritennResidentEvil1CheatsPc,
    @SerializedName("writenn resident evil 1 cheats psx")
    val writennResidentEvil1CheatsPsx: WritennResidentEvil1CheatsPsx,
    @SerializedName("writenn resident evil 1 cheats sega saturn")
    val writennResidentEvil1CheatsSegaSaturn: WritennResidentEvil1CheatsSegaSaturn,
    @SerializedName("youtube url")
    val youtubeUrl: String
)