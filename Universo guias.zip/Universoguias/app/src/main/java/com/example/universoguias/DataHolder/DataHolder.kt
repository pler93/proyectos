package com.example.universoguias.DataHolder

import android.icu.util.ULocale
import java.util.*

object DataHolder {
    val dbUsers = "users"
    val dbCategories = "categorias"
    val dbTasks = "tasks"
    var name = ""
    val dbName = "Universo guias"
    var currentCategory: Locale.Category? = null
}