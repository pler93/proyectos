package com.example.universoguias.utils

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import androidx.recyclerview.widget.GridLayoutManager
import com.example.universoguias.PaginasPrincipales.SagaResidentEvil
import com.example.universoguias.R
import com.example.universoguias.R.id.action_search
import com.example.universoguias.adapter.juegosadapters.JuegoAdapterRE1
import com.example.universoguias.modelsRE1.v2.Juego
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import kotlinx.android.synthetic.main.activity_guia_resident_evil1.*
import kotlinx.android.synthetic.main.activity_saga_resident_evil.*
import kotlinx.android.synthetic.main.activity_sagasde_videojuegos.*
import kotlinx.android.synthetic.main.container.*

class GuiaResidentEvil1 : AppCompatActivity() {

    private lateinit var adapter: JuegoAdapterRE1
    lateinit var db: FirebaseFirestore
    lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_guia_resident_evil1)
        setSupportActionBar(toolbar)

        initList()
        leerdatos()

        btnVolveraSagaResidentEvil.setOnClickListener{
            returnActivity()
            return@setOnClickListener
        }
    }

    private fun initList(){
        adapter = JuegoAdapterRE1(listOf()){
        }
        recyclerViewRE1.layoutManager = GridLayoutManager(this, 1)
        recyclerViewRE1.adapter = adapter
    }
    fun leerdatos(){
        db = Firebase.firestore

        val sagaslista = arrayListOf<Juego>()
        db.collection("sagas").get()
            .addOnSuccessListener {

                sagaslista.clear()
                for (document in it) {
                    var juego = document.toObject(Juego::class.java)
                    sagaslista.add(juego)
                }
                pintardatos(sagaslista)
            }
    }

    fun pintardatos(juego: List<Juego>){
        adapter.mDataSet = juego
        adapter.notifyDataSetChanged()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {

        menuInflater.inflate(R.menu.navmenu, menu)
        menuInflater.inflate(R.menu.menu_search, menu)

        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            action_search -> Log.i("PaginaPrincipal", "Search")
            action_search -> Log.i("SagasdeVideojuegos", "Search")
            action_search -> Log.i("SagaResidentEvil", "Search")
            action_search -> Log.i("GuiaResidentEvil1", "Search")
        }

        return super.onOptionsItemSelected(item)
    }
    fun returnActivity() {
        startActivity(Intent(this, SagaResidentEvil::class.java))
        finish()
        return
    }
}