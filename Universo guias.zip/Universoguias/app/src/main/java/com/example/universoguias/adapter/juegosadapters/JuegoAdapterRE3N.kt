package com.example.universoguias.adapter.juegosadapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.universoguias.R
import com.example.universoguias.modelsRE1.v2.Juego
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.item_residentevil3.view.*

class JuegoAdapterRE3N (var mDataSet: List<Juego>, var onClick: (Juego)->Unit) :
    RecyclerView.Adapter<JuegoAdapterRE3N.MainViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MainViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_residentevil3, parent, false)
        return MainViewHolder(v)
    }

    override fun onBindViewHolder(holder: MainViewHolder, position: Int) {
        val data = mDataSet.get(position)
        holder.bindItems(data)
        holder.itemView.setOnClickListener{
            onClick(data)
        }
    }

    override fun getItemCount(): Int {
        return mDataSet.size
    }

    inner class MainViewHolder(var v: View) : RecyclerView.ViewHolder(v) {
        fun bindItems(data: Juego) {
            v.tvTextRE3.text = data.nombre
            v.tvañoRE3.text = data.anio.toString()
            Picasso.get().load(data?.foto).into(v.ivResidentEvil3)
        }
    }
}