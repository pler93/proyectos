package com.example.universoguias.Users

class User {
    var nombre: String? = null
    var apellidos: String? = null
    var email: String? = null
}