package com.example.universoguias.modelsRE1.v2

class Saga(){
    var id: String = ""
    var nombre: String = ""
    var foto: String = ""
    var año: String = ""
}
data class Juego(
    var id: String,
    var nombre: String,
    var foto: String,
    var anio: Int,
    var idSaga: String,
    var descripcion: String,
    var agradeciemiento: String,
    var youtube: String,
    var mapas: List<Mapa>
)
data class Mapa(var nombre: String, var foto: String)