package com.example.universoguias

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.universoguias.utils.PaginaPrincipal
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.ktx.Firebase
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    val TAG = "miapp"
    lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        auth = FirebaseAuth.getInstance()
        btnRegister.setOnClickListener {
            val nombre = txtEdName.text!!.toString()
            val email = txtEdEmail.text!!.toString()
            val pass = txtEdPassword.text!!.toString()

            if (!isNameValid(nombre)) {
                txtEdName.error = "El nombre debe tener al menos 2 carácteres"
                return@setOnClickListener
            }
            if(!isEmailValid(email)) {
                txtEdEmail.error = "El email no es válido"
                return@setOnClickListener
            }
            if(!isPasswordValid(pass)) {
                txtEdPassword.error = "La contraseña debe tener min. 6 carácteres"
                return@setOnClickListener
            }
            Log.v(TAG, "TODO OK!! Estas registrado!")
            Toast.makeText(this, "Registro completo", Toast.LENGTH_LONG).show()
            nextActivity()
        }

        btnEntrar.setOnClickListener{
            nextActivity()
        }
    }

    fun isNameValid(name: String): Boolean {
        return name.length >= 2
    }

    fun isEmailValid(email: String): Boolean {
        return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }

    fun isPasswordValid(pass: String): Boolean {
        return pass.length >= 6
    }

    fun loginUser(email: String, password: String) {
        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {

                    Log.v(TAG, "signInWithEmail:success")
                    val user = auth.currentUser
                    PaginaPrincipal()

                } else {

                    Log.v(TAG, "signInWithEmail:failure", task.exception)
                    Toast.makeText(
                        applicationContext, "Authentication failed.",
                        Toast.LENGTH_SHORT
                    ).show()

                }
            }
    }

    public override fun onStart() {
        super.onStart()
        val currentUser = auth.currentUser
        if (currentUser != null) {
            PaginaPrincipal()
        }
    }

    fun nextActivity() {
        startActivity(Intent(this, PaginaPrincipal::class.java))
        finish()
    }
}