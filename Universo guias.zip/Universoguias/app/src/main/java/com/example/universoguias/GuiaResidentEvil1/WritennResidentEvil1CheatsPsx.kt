package com.example.universoguias.GuiaResidentEvil1


import com.google.gson.annotations.SerializedName

data class WritennResidentEvil1CheatsPsx(
    @SerializedName("change the clothes")
    val changeTheClothes: String,
    @SerializedName("change the difficulty during the game (only for the japanese version)")
    val changeTheDifficultyDuringTheGameOnlyForTheJapaneseVersion: String,
    @SerializedName("resident evil 1 cheats psx")
    val residentEvil1CheatsPsx: String,
    @SerializedName("rocket launcher with infinite ammunition")
    val rocketLauncherWithInfiniteAmmunition: String
)