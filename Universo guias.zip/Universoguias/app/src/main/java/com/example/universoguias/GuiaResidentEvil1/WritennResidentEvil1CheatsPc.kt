package com.example.universoguias.GuiaResidentEvil1


import com.google.gson.annotations.SerializedName

data class WritennResidentEvil1CheatsPc(
    @SerializedName("get the machine gun and the pistol")
    val getTheMachineGunAndThePistol: String,
    @SerializedName("new uniforms")
    val newUniforms: String,
    @SerializedName("resident evil 1 cheats pc")
    val residentEvil1CheatsPc: String,
    @SerializedName("rocket launcher")
    val rocketLauncher: String
)