package com.example.universoguias.GuiaResidentEvil1


import com.google.gson.annotations.SerializedName

data class ChrisCampaign(
    @SerializedName("tips")
    val tips: String,
    @SerializedName("written guide getting the shotgun")
    val writtenGuideGettingTheShotgun: String,
    @SerializedName("written guide hunter infested mansion and getting the magnum")
    val writtenGuideHunterInfestedMansionAndGettingTheMagnum: String,
    @SerializedName("written guide introduction")
    val writtenGuideIntroduction: String,
    @SerializedName("written guide The armor key and the sword key")
    val writtenGuideTheArmorKeyAndTheSwordKey: String,
    @SerializedName("written guide the basement of the garden house")
    val writtenGuideTheBasementOfTheGardenHouse: String,
    @SerializedName("written guide the basements of the mansion")
    val writtenGuideTheBasementsOfTheMansion: String,
    @SerializedName("written guide the emblem of the moon crest and the door of the medallions")
    val writtenGuideTheEmblemOfTheMoonCrestAndTheDoorOfTheMedallions: String,
    @SerializedName("written guide the emblem of the star crest")
    val writtenGuideTheEmblemOfTheStarCrest: String,
    @SerializedName("written guide the emblem of the sun crest")
    val writtenGuideTheEmblemOfTheSunCrest: String,
    @SerializedName("written guide the emblem of the wind and the shield key")
    val writtenGuideTheEmblemOfTheWindAndTheShieldKey: String,
    @SerializedName("written guide the garden")
    val writtenGuideTheGarden: String,
    @SerializedName("written guide the garden house")
    val writtenGuideTheGardenHouse: String,
    @SerializedName("written guide the garden house again")
    val writtenGuideTheGardenHouseAgain: String,
    @SerializedName("written guide the laboratory")
    val writtenGuideTheLaboratory: String,
    @SerializedName("written guide the mansion")
    val writtenGuideTheMansion: String,
    @SerializedName("written guide the undergrounds of the garden")
    val writtenGuideTheUndergroundsOfTheGarden: String
)