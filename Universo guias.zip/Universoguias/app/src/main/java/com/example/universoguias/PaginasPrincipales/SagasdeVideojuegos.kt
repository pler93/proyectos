package com.example.universoguias.PaginasPrincipales

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import androidx.recyclerview.widget.GridLayoutManager
import com.example.universoguias.R
import com.example.universoguias.adapter.SAdapter
import com.example.universoguias.modelsRE1.v2.Saga
import com.example.universoguias.utils.PaginaPrincipal
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import kotlinx.android.synthetic.main.activity_sagasde_videojuegos.*

import kotlinx.android.synthetic.main.container.toolbar

class SagasdeVideojuegos : AppCompatActivity() {
    private lateinit var adapter: SAdapter
    lateinit var db: FirebaseFirestore
    lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sagasde_videojuegos)
        setSupportActionBar(toolbar)

        db = Firebase.firestore
        initList()
        leerdatos()

    }
    private fun initList(){
        adapter = SAdapter(listOf()){

        }
        recyclerView.layoutManager = GridLayoutManager(this, 3)
        recyclerView.adapter = adapter
    }
    fun leerdatos(){
        db = Firebase.firestore

        val sagaslista = arrayListOf<Saga>()
        db.collection("sagas").get()
            .addOnSuccessListener {

                sagaslista.clear()
                for (document in it) {
                    var saga = document.toObject(Saga::class.java)
                    sagaslista.add(saga)
                }
                pintardatos(sagaslista)
            }
    }

    fun pintardatos(sagaslista: List<Saga>){
        adapter.mDataSet = sagaslista
        adapter.notifyDataSetChanged()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {

        menuInflater.inflate(R.menu.navmenu, menu)
        menuInflater.inflate(R.menu.menu_search, menu)

        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_search -> Log.i("PaginaPrincipal", "Search")
            R.id.action_search -> Log.i("SagasdeVideojuegos", "Search")
            R.id.action_search -> Log.i("SagaResidentEvil", "Search")
            R.id.action_search -> Log.i("GuiaResidentEvil1", "Search")
        }

        return super.onOptionsItemSelected(item)
    }

    fun nextActivity() {
        startActivity(Intent(this, SagaResidentEvil::class.java))
        finish()
        return
    }

    fun nextActivity1() {
        startActivity(Intent(this, SagaResidentEvil::class.java))
        finish()
        return
    }

    fun returnActivity() {
        startActivity(Intent(this, PaginaPrincipal::class.java))
        finish()
        return
    }
}