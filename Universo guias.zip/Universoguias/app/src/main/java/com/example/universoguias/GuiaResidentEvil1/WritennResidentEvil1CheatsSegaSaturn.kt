package com.example.universoguias.GuiaResidentEvil1


import com.google.gson.annotations.SerializedName

data class WritennResidentEvil1CheatsSegaSaturn(
    @SerializedName("alternative costumes")
    val alternativeCostumes: String,
    @SerializedName("battle game")
    val battleGame: String,
    @SerializedName("missile launchers with infinite ammunition")
    val missileLaunchersWithInfiniteAmmunition: String,
    @SerializedName("resident evil 1 cheats sega saturn")
    val residentEvil1CheatsSegaSaturn: String
)