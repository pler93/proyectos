package com.example.universoguias.utils

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.widget.SearchView
import com.example.universoguias.R
import com.example.universoguias.R.id.action_search
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_pagina_principal.*
import kotlinx.android.synthetic.main.container.*
import kotlinx.android.synthetic.main.container.toolbar

class PaginaPrincipal : AppCompatActivity() {

    lateinit var auth: FirebaseAuth
    lateinit var db: FirebaseFirestore
    val TAG = "miapp"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pagina_principal)
        setSupportActionBar(toolbar)
        btnIrSagasdeVideojuegos.setOnClickListener{
            SagasdeVideojuegos()
            return@setOnClickListener
        }
        btnIrPatreon.setOnClickListener{
            Patreon()
            return@setOnClickListener
        }
        btnIrAgradecimientos.setOnClickListener{
            Agradecimientos()
            return@setOnClickListener
        }
        btnFavoritos.setOnClickListener{
            Favoritos()
            return@setOnClickListener
        }
        btnIrJuegosmasfamosos.setOnClickListener{
            Juegosmasfamosos()
            return@setOnClickListener
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        super.onCreateOptionsMenu(menu)
        menuInflater.inflate(R.menu.navmenu, menu)
        menuInflater.inflate(R.menu.menu_search, menu)
        val searchView: SearchView = menu?.findItem(R.id.app_bar_search)?.actionView as SearchView
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                onSearch(query)
                return true
            }
            override fun onQueryTextChange(query: String?): Boolean {
                onSearch(query)
                return true
            }
        })
        return super.onCreateOptionsMenu(menu)
    }
    private fun onSearch(query: String?) {
        query?.let { Log.d(TAG, query) }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            action_search -> Log.i("PaginaPrincipal", "Search")
            action_search -> Log.i("SagasdeVideojuegos", "Search")
            action_search -> Log.i("Patreon", "Search")
            action_search -> Log.i("Agradecimientos", "Search")
            action_search -> Log.i("Favoritos", "Search")
            action_search -> Log.i("Juegosmasfamosos", "Search")
            action_search -> Log.i("SagaResidentEvil", "Search")
            action_search -> Log.i("GuiaResidentEvil1", "Search")
            action_search -> Log.i("item_residentevil1", "Search")
        }
        return super.onOptionsItemSelected(item)
    }

    fun SagasdeVideojuegos() {
        startActivity(Intent(this, com.example.universoguias.PaginasPrincipales.SagasdeVideojuegos::class.java))
        finish()
        return
    }

    fun Favoritos() {
        startActivity(Intent(this, com.example.universoguias.PaginasPrincipales.Favoritos::class.java))
        finish()
        return
    }

    fun Juegosmasfamosos() {
        startActivity(Intent(this, com.example.universoguias.PaginasPrincipales.Juegosmasfamosos::class.java))
        finish()
        return
    }

    fun Patreon() {
        startActivity(Intent(this, com.example.universoguias.PaginasPrincipales.Patreon::class.java))
        finish()
        return
    }

    fun Agradecimientos() {
        startActivity(Intent(this, com.example.universoguias.PaginasPrincipales.Agradecimientos::class.java))
        finish()
        return
    }
}